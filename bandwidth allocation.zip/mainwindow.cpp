#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QGraphicsEllipseItem>
#include <QGraphicsTextItem>
#include <QtMath>
#include <queue>
#include <QDate>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    scene = new QGraphicsScene(this);

    // Yahan check hoga ki aapne UI mein 'graphView' banaya hai ya nahi
    if(ui->graphView) {
        ui->graphView->setScene(scene);
    }
}

MainWindow::~MainWindow() { delete ui; }

// --- Edmonds-Karp Logic ---
bool MainWindow::bfs(int rGraph[100][100], int s, int t, int parent[], int n) {
    bool visited[100] = {false};
    std::queue<int> q;
    q.push(s);
    visited[s] = true;
    parent[s] = -1;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v = 0; v < n; v++) {
            if (!visited[v] && rGraph[u][v] > 0) {
                if (v == t) { parent[v] = u; return true; }
                q.push(v); parent[v] = u; visited[v] = true;
            }
        }
    }
    return false;
}

int MainWindow::edmondsKarp(int graph[100][100], int source, int sink, int n) {
    int rGraph[100][100];
    for (int i=0; i<n; i++) for (int j=0; j<n; j++) rGraph[i][j] = graph[i][j];
    int parent[100], maxFlow = 0;
    while (bfs(rGraph, source, sink, parent, n)) {
        int pathFlow = 1e9;
        for (int v=sink; v!=source; v=parent[v]) pathFlow = std::min(pathFlow, rGraph[parent[v]][v]);
        for (int v=sink; v!=source; v=parent[v]) {
            rGraph[parent[v]][v] -= pathFlow;
            rGraph[v][parent[v]] += pathFlow;
        }
        maxFlow += pathFlow;
    }
    return maxFlow;
}

// --- Button Actions ---
void MainWindow::on_btnGenerate_clicked() {
    int n = ui->nodecount->value();
    ui->networkTable->setRowCount(n);
    ui->networkTable->setColumnCount(n);
    for(int i=0; i<n; i++) {
        for(int j=0; j<n; j++) ui->networkTable->setItem(i, j, new QTableWidgetItem("0"));
    }
}

void MainWindow::on_btnAddUser_clicked() {
    int row = ui->userTable->rowCount();
    ui->userTable->insertRow(row);

    // 1. Name
    ui->userTable->setItem(row, 0, new QTableWidgetItem("User " + QString::number(row + 1)));

    // 2. Target Node
    ui->userTable->setItem(row, 1, new QTableWidgetItem(QString::number(row + 2)));

    // 3. Package Dropdown (Ye auto-fill aur speed connect karega)
    QComboBox* combo = new QComboBox();
    combo->addItems({"Basic", "Standard", "Premium"});
    ui->userTable->setCellWidget(row, 2, combo);

    // 4. Default Speed (Basic ke liye 10)
    ui->userTable->setItem(row, 3, new QTableWidgetItem("10"));

    // 5. Date & Validity Auto-fill
    QString currentDate = QDate::currentDate().toString("dd-MM-yyyy");
    ui->userTable->setItem(row, 4, new QTableWidgetItem(currentDate));
    ui->userTable->setItem(row, 5, new QTableWidgetItem("30 Days"));

    // 6. Connection: Jab package badle toh speed apne aap badle
    connect(combo, &QComboBox::currentTextChanged, [this, row](const QString &text){
        if(text == "Premium") ui->userTable->item(row, 3)->setText("50");
        else if(text == "Standard") ui->userTable->item(row, 3)->setText("30");
        else ui->userTable->item(row, 3)->setText("10");
    });
}

void MainWindow::on_btnAllocate_clicked() {
    if(!ui->resultDisplay || !scene) return;
    scene->clear();
    ui->resultDisplay->clear();

    int n = ui->nodecount->value();
    int graph[100][100] = {0};

    // Table se data lena
    for (int i=0; i<n; i++) {
        for (int j=0; j<n; j++) {
            if(ui->networkTable->item(i,j)) graph[i][j] = ui->networkTable->item(i,j)->text().toInt();
        }
    }

    // Nodes Draw karna
    for (int i=0; i<n; i++) {
        double x = 150 * cos(6.28*i/n) + 150;
        double y = 100 * sin(6.28*i/n) + 100;
        scene->addEllipse(x, y, 30, 30, QPen(Qt::black), QBrush(i==0?Qt::black:Qt::cyan));
        scene->addText(QString::number(i))->setPos(x+10, y+5);
    }

    ui->resultDisplay->append("Allocation Finished.");
}

// --- Navigation ---
void MainWindow::on_btnNextToTab2_clicked() { ui->tabWidget->setCurrentIndex(1); }
void MainWindow::on_btnBackToTab1_clicked() { ui->tabWidget->setCurrentIndex(0); }
void MainWindow::on_btnNextToTab3_clicked() { ui->tabWidget->setCurrentIndex(2); }
void MainWindow::on_btnBackToTab2_clicked() { ui->tabWidget->setCurrentIndex(1); }
void MainWindow::on_btnAllocateBandwidth_clicked() {
    if(!ui->resultDisplay || !scene) return;

    scene->clear();
    ui->resultDisplay->clear();

    int n = ui->nodecount->value();
    int graph[100][100] = {0};

    // 1. Matrix se data lena
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if(ui->networkTable->item(i, j))
                graph[i][j] = ui->networkTable->item(i, j)->text().toInt();
        }
    }

    // 2. Nodes Draw karna (Graph Visualization)
    QMap<int, QPointF> nodePositions;
    for (int i = 0; i < n; i++) {
        double angle = 6.28 * i / n;
        double x = 150 * cos(angle) + 150;
        double y = 100 * sin(angle) + 100;
        nodePositions[i] = QPointF(x + 15, y + 15);

        scene->addEllipse(x, y, 30, 30, QPen(Qt::black), QBrush(i == 0 ? Qt::black : Qt::cyan));
        QGraphicsTextItem* text = scene->addText(QString::number(i));
        text->setPos(x + 10, y + 5);
        if(i == 0) text->setDefaultTextColor(Qt::white);
    }

    // 3. Edges (Lines) draw karna
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (graph[i][j] > 0) {
                scene->addLine(nodePositions[i].x(), nodePositions[i].y(),
                               nodePositions[j].x(), nodePositions[j].y(), QPen(Qt::gray));
            }
        }
    }

    // 4. Bandwidth Allocation Report
    ui->resultDisplay->append("<b style='color:blue;'>ISP ALLOCATION REPORT</b><br>");
    for (int i = 0; i < ui->userTable->rowCount(); i++) {
        QString name = ui->userTable->item(i, 0)->text();
        int target = ui->userTable->item(i, 1)->text().toInt();
        int req = ui->userTable->item(i, 3)->text().toInt();

        // Edmonds-Karp call karna (Source hamesha 0)
        int max_avail = edmondsKarp(graph, 0, target, n);

        QString status = (max_avail >= req) ?
                             "<span style='color:green;'> SUCCESS</span>" :
                             "<span style='color:red;'> CONGESTED</span>";

        ui->resultDisplay->append(QString("<b>User:</b> %1 | <b>Node:</b> %2<br><b>Required:</b> %3 Mbps | <b>Available:</b> %4 Mbps<br><b>Status:</b> %5<br>--------------------------")
                                      .arg(name).arg(target).arg(req).arg(max_avail).arg(status));
    }
}

void MainWindow::on_btnClose_clicked()
{
    this->close();
}

