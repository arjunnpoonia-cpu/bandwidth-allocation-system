#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QComboBox>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btnGenerate_clicked();
    void on_btnAddUser_clicked();
    void on_btnAllocate_clicked();
    void on_btnNextToTab2_clicked();
    void on_btnBackToTab1_clicked();
    void on_btnNextToTab3_clicked();
    void on_btnBackToTab2_clicked();
    void on_btnAllocateBandwidth_clicked();
    void on_btnClose_clicked();

private:
    Ui::MainWindow *ui;
    QGraphicsScene *scene; // Isse hum manually handle karenge

    bool bfs(int rGraph[100][100], int s, int t, int parent[], int n);
    int edmondsKarp(int graph[100][100], int source, int sink, int n);
};

#endif // MAINWINDOW_H